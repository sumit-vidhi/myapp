import { InjectionToken } from '@angular/core';

const _isDev = window.location.port.indexOf('4200') > -1;

const protocol = window.location.protocol;

const host = window.location.host;

const apiURI = _isDev ? 'http://localhost:3001/api/' : '/api/';


export const CNF = {
	appName : 'WellFaster',
  	BASE_URI: protocol + "//" + host + '/',
  	BASE_API: apiURI,
  	GOOGLE: {
  		CLIENT_ID : '463694952815-de19uf0rdgk2s7o7or3jpda2b5kvg35v.apps.googleusercontent.com'
  	},
  	FACEBOOK: {
  		APP_ID : '287922191709977'
  	} 
};

