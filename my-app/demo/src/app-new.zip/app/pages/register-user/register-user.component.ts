import { 
	Component, 
	OnInit
} 							from '@angular/core';

import { 
	FormBuilder, 
	FormGroup,
	Validators
} 							from '@angular/forms';

import * as _ 								from 'underscore';

import { UtilService }		from '../../core/util.service';
import { DataService }		from '../../core/data.service';

import { Country }			from '../../models/country';
import { UserRegisterForm }	from '../../models/user-register-form';


function passwordMatchValidator(g: FormGroup) {
   return g.get('password').value === g.get('confirm_password').value
      ? null : {'mismatch': true};
}


@Component({
  	selector: 'app-register-user',
 	templateUrl: './register-user.component.html',
  	styleUrls: ['./register-user.component.css']
})


export class RegisterUserComponent implements OnInit {

	constructor(
		private fb  : FormBuilder,
		public 	util : UtilService,
		private dataService : DataService
	){}
	
	/**
	 *  BOOTSTRAP TAB VARIABLES & FUNCTIONS
	 */

		activeTab:number=1;
		disabledTabs:any=[2,3,4];

		showTab(tabId:number){
			if(!this.isTabDisabled(tabId))
				this.activeTab = tabId;
		}

		isTabActive(tabId:number):boolean{
			return this.activeTab === tabId;
		}
		isTabDisabled(tabId:number):boolean{
			return this.disabledTabs.indexOf(tabId) >= 0;
		}
		makeActive(tabId:number){
			let i = this.disabledTabs.indexOf(tabId);
			if(i >= 0){
				this.disabledTabs.splice(i,1);
			}
			return true;
		}


	/**
	 *  USER REGISRATION FORMS
	 */

		model = new  UserRegisterForm()
		regForm1 : FormGroup;
		regForm2 : FormGroup;
		regForm3 : FormGroup;
		regForm4 : FormGroup;

		createRegForms(){
			
			// CREATE RegForm1 
			this.regForm1 = this.fb.group({	 
				first_name 	: ['kuldeep', Validators.required],
				last_name  	: ['semwal', Validators.required],
				nickname 	: ['deep', Validators.required],
				birth_date 	: ['11/11/1989', Validators.required],
				phone_number: ['1234567878', [ 
					Validators.minLength(10),
					Validators.maxLength(10),
					Validators.pattern("[0-9]*")
				]],
				email 		: ['kuldeep@wegile.com', [ Validators.required,Validators.email ]],
				password 	: ['123456', [
					Validators.required,
					Validators.minLength(6),
					Validators.maxLength(20),
				]],
				confirm_password : ['123456', Validators.required],
				step:this.activeTab
			},{ 
				validator : passwordMatchValidator
			});

			// CREATE RegForm2 
			this.regForm2 = this.fb.group({	 
				street 	: ['', Validators.required],
				street1 : [''],
				city  	: ['', Validators.required],
				state 	: ['', Validators.required],
				country : ['', Validators.required],
				zip : ['', [
					Validators.required,
					Validators.minLength(5),
					Validators.maxLength(6),
					Validators.pattern("[0-9]*"),
				]],
				timezone : ['', Validators.required],
				clock_display : ['', Validators.required],
				preferred_langauge : ['', Validators.required],
				second_langauge : [''],
				step:this.activeTab
			});

			// CREATE RegForm2 
			this.regForm3 = this.fb.group({	 
				height 	: ['', [
					Validators.required,
					Validators.pattern("[0-9]*")
				]],
				weight 	: ['', [
					Validators.required,
					Validators.pattern("[0-9]*")
				]],
				unit  	: ['', Validators.required],
				sleep_senstivity 	: ['dasd', Validators.required],
				stride_length : ['',[
					Validators.required,
					Validators.pattern("[0-9]*")
				]],
				heart_rate_zones : ['', Validators.required],
				step:this.activeTab
			});

			// CREATE RegForm3 
			this.regForm4 = this.fb.group({	 
				start_week:[''],
				description:[''],
				accept:['', Validators.required],
				step:this.activeTab
			});

		}	

		regUserBack(){
			if(this.activeTab > 1) this.activeTab--;
		}

		regUser(form){
			switch(form.step){
				case 1:
					if(form.step===1){ 
						this.model.first_name = form.first_name;
						this.model.last_name = form.last_name;
						this.model.nickname = form.nickname;
						this.model.birth_date = form.birth_date;
						this.model.phone_number = form.phone_number;
						this.model.email = form.email;
						this.model.password = form.password;
						this.model.confirm_password = form.confirm_password;
						
						if(this.makeActive(2)) {
							this.showTab(2);
							this.regForm2.get('step').setValue(2);
							this.regForm2.get('step').updateValueAndValidity();
						}	

					}
					break;
				case 2:
					if(form.step===2){ 
						this.model.street = form.street +';'+form.street1;
						this.model.city = form.last_name;
						this.model.state = form.nickname;
						this.model.country = form.birth_date;
						this.model.zip = form.phone_number;
						this.model.timezone = form.email;
						this.model.clock_display = form.password;
						this.model.preferred_language = form.confirm_password;
						this.model.second_language = form.confirm_password;
						if(this.makeActive(3)) {
							this.showTab(3);
							this.regForm3.get('step').setValue(3);
							this.regForm3.get('step').updateValueAndValidity();
						}
					}
					break;
				case 3:
					if(form.step===3){ 
						this.model.height = form.height;
						this.model.weight = form.weight;
						this.model.unit = form.unit;
						this.model.heart_rate_zones = form.heart_rate_zones;
						this.model.sleep_senstivity = form.sleep_senstivity;
						this.model.stride_length = form.stride_length	;
						if(this.makeActive(4)) {
							this.showTab(4);
							this.regForm4.get('step').setValue(4);
							this.regForm4.get('step').updateValueAndValidity();
						}
					}
					break;
				case 4:
					if(form.step===4){ 
						this.model.start_week = form.start_week;
						this.model.description = form.description;
						this.saveUser();
					}
					break;			
			}
		}

		saveUser(){}

	/**
	 *  FUCNTIONS FOR GET JSON
	 */
		countries:any;
		states:any;
		cities:any;
		timezones:any;
		languages:any;

		refreshStates(event:any){
			let countryId = event.target.value;
			this.getStates(countryId);
		}
	
		refreshCities(event:any){
			// this.getCities(event.target.value);
		}
	
		getCountries(): void {
			this.dataService.getCountries() 
			  .subscribe(x => this.countries = x);
		}
		
		getCities(sId?:number): void {
			this.dataService.getCities() 
			  .subscribe(x => {
				for(let i in x){
					if(sId && x[i].state_id == sId){
							x[i].text = x[i].name; 
							delete x[i].state_id;
							delete x[i].name;
					}else{
						x.splice(i,1);
					}
				}
				this.cities = x;
			});
		}
	
		getStates(cId?:number): void {
			this.dataService.getStates() 
			  .subscribe(x => {
				this.states = (cId) ? _.where(x,{ country_id : cId}) : x;
			});
		}
	
		getLanguages(): void {
			this.dataService.getLanguages() 
			  .subscribe(x => {
				this.languages = x;
			});
		}
	
		getTimezones(): void {
			this.dataService.getTimezones() 
			  .subscribe(x => {
				let arr = [];  
				for(let i in x){
					arr.push(x[i]);
				}
				this.timezones = arr;
			});
		}

	ngOnInit() {
		this.createRegForms();
		this.getCountries();
		if(this.regForm2.get('country').value != ''){
			this.getStates(this.regForm2.get('country').value);
		}
		this.getTimezones();
		this.getLanguages();
	}

}
