import { 
	Component, 
	OnInit,
	TemplateRef 
} 							from '@angular/core';

import { 
	FormBuilder, 
	FormGroup,
	FormArray,
	Validators
} 							from '@angular/forms';

import { 
	Router 
} 							from '@angular/router';

import { BsModalService } 	from 'ngx-bootstrap/modal';
import { BsModalRef } 		from 'ngx-bootstrap/modal/bs-modal-ref.service';
 

import * as _ 				from 'underscore';

import { ApiService }		from '../../core/api.service';
import { AuthService }		from '../../core/auth.service';
import { UtilService }		from '../../core/util.service';
import { DataService }		from '../../core/data.service';

import { TabForm } 			from '../../models/tab-form';

import { UserProfile } from '../../models/user-profile';

/**
 * Funtion used for comparing password
 * @param g 
 */
function passwordMatchValidator(g: FormGroup) {
   return g.get('password').value === g.get('confirm_password').value
      ? null : {'mismatch': true};
}


@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css'],
  
})
export class AccountComponent extends TabForm implements OnInit {

	modalRef: BsModalRef;
	states:any;
    
	userForm : FormGroup;
	trainerForm : FormGroup;
	model:any;

	imageChangedEvent: any = '';
	croppedImage: any = '';
	isImageCropped:boolean=false;
	certArr:any=[];


	spArr:any=[
		{value:'general_fitness', name:'general fitness'},
		{value:'strenght_training', name:'strenght training'},
		{value:'weight_loss', name:'weight loss'},
		{value:'endurence', name:'endurence'},
		{value:'diet_and_nutritions', name:'diet and nutritions'},
		{value:'plyometrics', name:'plyometrics'},
		{value:'speed_and_agility', name:'speed and gility'},
		{value:'functional_training', name:'functional training'},
		{value:'high_intensity_interval', name:'high intensity interval'},
		{value:'other', name:'other'},
	];

	cer

  constructor(
		private fb  		: FormBuilder,
		public  auth    : AuthService,
		private api			:	ApiService,
		private router  : Router,
		public 	util 		: UtilService,
		public dataService:DataService,
		private modalService: BsModalService
	){
		super(1,4,dataService);
	}

	
	fileChangeEvent(event: any): void {
		this.imageChangedEvent = event;
	}

	imageCropped(image: string) {
		this.croppedImage = image;
	}

	cropImage(){
		this.userForm.get('photo').setValue(this.croppedImage);
		this.modalRef.hide();
	}

	
	openModal(template: TemplateRef<any>) {
		this.modalRef = this.modalService.show(template);
	}

	onNext(){
		if(this.userForm.valid){
			const formModal = this.userForm.value;
			if(this.activeTab < 4){
				this.goNext();
			}else{ 
				this.saveUser();	
			}	
		}
	}

	onBack(){
		if(this.activeTab > 1) this.activeTab--;
	}
	
	refreshStates(event?:any){
		if(event){

		}else{
			this.states = this.allStates;
		}
	}


	addCertificate(){
		(this.trainerForm.get('certifications') as FormArray).push(this.fb.group({
		  text:''
		}));
	}
  
	deleteCertificate(i:number){
		(this.trainerForm.get('certifications') as FormArray).removeAt(i);
	}
  
	addEducation(){
		(this.trainerForm.get('educations') as FormArray).push(this.fb.group({
		  text:''
		}));
	}
  
	deleteEducation(i:number){
		(this.trainerForm.get('educations') as FormArray).removeAt(i);
	}

	createUserForm(){
		this.userForm = this.fb.group({	 
			step1:this.fb.group({
				first_name 	: ['', Validators.required],
				last_name  	: ['', Validators.required],
				nickname 	: ['', Validators.required],
				birth_date 	: ['', Validators.required],
				phone_number: ['', [ 
					Validators.minLength(10),
					Validators.maxLength(10),
					Validators.pattern("[0-9]*")
				]],
				email 		: ['', [ Validators.required,Validators.email ]]
			}),
			step2:this.fb.group({
				street 	: ['', Validators.required],
				street1 : [''],
				city  	: ['', Validators.required],
				state 	: ['', Validators.required],
				country : ['', Validators.required],
				zip : ['', [
					Validators.required,
					Validators.minLength(5),
					Validators.maxLength(6),
					Validators.pattern("[0-9]*"),
				]],
				timezone : ['', Validators.required],
				clock_display : ['24', Validators.required],
				preferred_language : ['', Validators.required],
				second_language : ['']
			}),
			step3:this.fb.group({
				height 	: ['', [
					Validators.required,
					Validators.pattern("[0-9]*")
				]],
				weight 	: ['', [
					Validators.required,
					Validators.pattern("[0-9]*")
				]],
				unit  	: ['', Validators.required],
				sleep_senstivity 	: ['', Validators.required],
				stride_length : ['',[
					Validators.required,
					Validators.pattern("[0-9]*")
				]],
				heart_rate_zones : ['', Validators.required],
			}),
			step4:this.fb.group({
				start_week:[''],
				description:['']
			}),
			photo:''
		})
	}	

	createTrainerForm(accModel:any){
		this.trainerForm = this.fb.group({	 
			step1:this.fb.group({
				first_name 	: ['', Validators.required],
				last_name  	: ['', Validators.required],
				nickname 	: ['', Validators.required],
				birth_date 	: ['', Validators.required],
				phone_number: ['', [ 
					Validators.minLength(10),
					Validators.maxLength(10),
					Validators.pattern("[0-9]*")
				]],
				email 		: ['', [ Validators.required,Validators.email ]]
			}),
			step2:this.fb.group({
				street 	: ['', Validators.required],
				street1 : [''],
				city  	: ['', Validators.required],
				state 	: ['', Validators.required],
				country : ['', Validators.required],
				zip : ['', [
					Validators.required,
					Validators.minLength(5),
					Validators.maxLength(6),
					Validators.pattern("[0-9]*"),
				]],
				timezone : ['', Validators.required],
				clock_display : ['24', Validators.required],
				preferred_language : ['', Validators.required],
				second_language : ['']
			}),
			step3:this.fb.group({
				specialities : this.fb.array([
					this.fb.group({general_fitness:false}),
					this.fb.group({strenght_training:false}),
					this.fb.group({weight_loss:false}),
					this.fb.group({endurence:false}),
					this.fb.group({diet_and_nutritions:false}),
					this.fb.group({plyometrics:false}),
					this.fb.group({speed_and_agility:false}),
					this.fb.group({functional_training:false}),
					this.fb.group({high_intensity_interval:false}),
					this.fb.group({other:false})
			 	]),
				certifications:this.fb.array([
					this.fb.group({ text:''}),
				]),
				educations:this.fb.array([
					this.fb.group({ text:''}),
				]),
				haveEducations:['1'],
				haveCertifications:['1'],
				short_description:[''],
			}),
			step4:this.fb.group({
				price_week:['', [
					Validators.required, 
					Validators.pattern("[0-9]*"), 
				]],
				description:[''],
			}),
			photo:''
		})
	}	

	createSetForm(accModel:any){
		if(accModel.role === 2){
			this.createTrainerForm(accModel);
			this.setTrainerForm(accModel);
		}else{
			this.createUserForm();
			//this.setUserForm(accModel);
		}
	}
	setUserForm(accModel:any){
		this.userForm.setValue({
			step1 : {
				first_name : 'deep',
				last_name:'semwal',
				nickname:'deep',
				birth_date:'11/12/1999',
				email:'kuldeep@wegile.com',
				phone_number:'1234567878'
			},
			step2:{
				street : 'fasdfasd',
				street1 : 'fasdfasd',
				country : '101',
				state:'32',
				city:'Mohali',
				zip:'12345',
				timezone:'GMT+05:30',
				clock_display:'24',
				preferred_language:'en',
				second_language:'hi'

			},
			step3:{
				height:'45',
				weight:'125',
				unit:'cm.kg.ml',
				sleep_senstivity:'das',
				stride_length:'45',
				heart_rate_zones:'faesdfsd fasdfsd'
			},
			step4:{
				start_week:'11/21/2017',
				description:''
			},
			photo:'assets/images/bh.jpg'
		});
	}

	setTrainerForm(accModel:any){
		let street = accModel.street.split(',');
		let specialities:any=[];
		let certifications:any=[];
		let educations:any=[];
		
		
		for(let i of this.spArr){
			let group = {};
			group[i.value]=true;
			specialities.push(group);
		}

		console.log(JSON.stringify(specialities));

		for(let i of accModel.certifications.split(',')){
			certifications.push({
				text : i
			});
		}

		for(let i of accModel.education.split(',')){
			educations.push({
				text : i
			});
		}

		console.log('specialities ===' + specialities);
		
		this.trainerForm.setValue({
			step1 : {
				first_name : accModel.first_name,
				last_name: accModel.last_name,
				nickname:accModel.nick_name,
				birth_date:accModel.birth_date,
				email:accModel.email,
				phone_number:accModel.phone_number
			},
			step2:{
				street : street[0],
				street1 : street[1],
				country : (accModel.country)?accModel.country:'101',
				state:(accModel.state)?accModel.state:'101',
				city:accModel.city,
				zip:accModel.zip,
				timezone:accModel.zip,
				clock_display:(accModel.clock_display)?accModel.clock_display:'24',
				preferred_language:(accModel.preferred_language)?accModel.preferred_language:'en',
				second_language:(accModel.second_language)?accModel.second_language:'hi'
			},
			step3:{
				specialities:specialities,
				certifications:certifications,
				educations:educations,
				haveEducations: (educations.length > 0) ? '1':'0',
				haveCertifications:(certifications.length > 0) ? '1':'0',
				short_description:accModel.description,
			},
			step4:{
				price_week:accModel.weeklyprice,
				description:accModel.addtional_description
			},
			photo:'assets/images/user2.png'
		});
	}
	
	saveUser(){
		let self = this;
		this.model = this.prepareSave();
		this.api.register(this.model)
		.then(function(res){
			if(res.code === 200){  // if server response is success go to finish page.
				self.router.navigate(['register/finish']);
			}
		});
	}

	prepareSave(){
		let formModal = this.userForm.value;
		let userModal:UserProfile={
			first_name: formModal.step1.first_name,
			last_name:formModal.step1.last_name,
			nickname:formModal.step1.nickname,
			birth_date:formModal.step1.birth_date,
			phone_number:formModal.step1.phone_number,
			email:formModal.step1.phone_number,
		
			street:formModal.step2.street,
			street1:formModal.step2.street1,
			city:formModal.step2.city,
			state:formModal.step2.state,
			country:formModal.step2.country,
			zip:formModal.step2.zip,
			timezone:formModal.step2.timezone,
			clock_display:formModal.step2.clock_display,
			preferred_language:formModal.step2.preferred_language,
			second_language:formModal.step2.second_language,
		
			height:formModal.step3.height,
			weight:formModal.step3.weight,
			unit:formModal.step3.unit,
			heart_rate_zones:formModal.step3.timezone,
			sleep_senstivity:formModal.step3.sleep_senstivity,
			stride_length:formModal.step3.stride_length,
		
			start_week:formModal.step4.start_week,
			description:formModal.step4.description,
			action:'',
			role:1
		}
		return userModal;
	}

	ngOnInit(){
		if(this.auth.user){
			this.createSetForm(this.auth.user);
		}
		this.getCountries().subscribe(x => this.allCountries=x);
		this.getStates().subscribe(x=> {
			this.allStates = x;
			this.refreshStates();
		});
		this.getTimezones().subscribe(x=>this.allTimezones=x);
		this.getLanguages().subscribe(x=>this.allLanguages=x);
	}
}
