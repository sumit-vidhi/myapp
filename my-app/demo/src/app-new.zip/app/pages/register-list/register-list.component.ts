import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-list',
  templateUrl: './register-list.component.html',
  styleUrls: ['./register-list.component.css']
})
export class RegisterListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
