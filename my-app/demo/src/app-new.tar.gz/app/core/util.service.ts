import { Injectable } from '@angular/core';

@Injectable()

export class UtilService {

  constructor() { }

	time(arg?:string, n?:number){
  		var now = new Date();
  		var time  = now.getTime();
  		if(arg){
			switch(arg){
				case 'H' : 
					time = (n)? (time + (36000000*n)) : (time + 36000000);
					break;
				case 'D' : 
					time = (n)? (time + (86400000*n)) : (time + 86400000);
					break;
				case 'W' : 
					time = (n)? (time + (604800000*n)) : (time + 604800000);	
					break;	
	  		}
	  	}
	  	return time;	
	}

	date(y?:number,m?:number,d?:number){
  		var date = new Date();
			date = new Date();
			if(y) date.setFullYear(y,0,0);
			if(m) date.setMonth(--m);
			if(d) date.setDate(d);
			date.setHours(0);
			date.setMinutes(0);
			date.setSeconds(0);
			date.setMilliseconds(0);
		return date;
	}

	prevDay(){
		var date = this.date();
		date.setDate(date.getDate()-1);
		return date;
	}
	
	nextDay(){
		var date = this.date();
		date.setDate(date.getDate()+1);
		return date;
	}

	addToDate(arg?:string, n?:number){
		var date = this.date();
		if(arg){
			switch(arg){
				case 'DAY' : 
					if(n)
						date.setDate(date.getDate()+n);
					break	
				case 'MONTH' : 
					if(n)
						date.setMonth(date.getMonth()+n);
					break	

	  		}
	  	}
	  	return date;
	}




}
