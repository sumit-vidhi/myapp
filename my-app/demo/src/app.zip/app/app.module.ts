import { NgModule, Pipe, PipeTransform } 	from '@angular/core';
import { BrowserModule } 					from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule }  from '@angular/forms';
import { HttpClientModule } 				from '@angular/common/http';
import { CustomFormsModule } 				from 'ng2-validation'
import { Ng2Webstorage } 					from 'ng2-webstorage';
import { DomSanitizer } 					from '@angular/platform-browser';
import { AlertModule } 						from 'ngx-bootstrap';
import { BsDropdownModule } 				from 'ngx-bootstrap';
import { TabsModule } 						from 'ngx-bootstrap';
import { BsDatepickerModule } 				from 'ngx-bootstrap'

/***********************************
 | IMPORING MODULES
 ***********************************/

import { CoreModule } 						from './core/core.module';
import { AppRoutingModule } 				from './app-routing.module';


/***********************************
 | IMPORING DIRECTIVES
 ***********************************/



/***********************************
 | IMPORING COMPONENTS
 ***********************************/

import { AppComponent } 					from './app.component';

import  * as Pages 							from './pages';
import { LoginComponent } from './layouts/login/login.component';
import { LoginLayoutComponent } from './layouts/login-layout/login-layout.component';
import { AppLayoutComponent } from './layouts/app-layout/app-layout.component';
import { AppHeaderComponent } from './layouts/app-header/app-header.component';
import { AppFooterComponent } from './layouts/app-footer/app-footer.component';




@Pipe({ name: 'safeHtml'})

export class SafeHtmlPipe implements PipeTransform  {
  constructor(private sanitized: DomSanitizer) {}
  transform(value) {
    return this.sanitized.bypassSecurityTrustHtml(value);
  }
}

@NgModule({
	imports : [ 
		BrowserModule, 
		FormsModule, 
		ReactiveFormsModule,
		HttpClientModule, 
		AppRoutingModule,
    	CoreModule.forRoot(),
		AlertModule.forRoot(),
		BsDropdownModule.forRoot(),
		TabsModule.forRoot(),
		BsDatepickerModule.forRoot(),
		Ng2Webstorage,
		CustomFormsModule
	],
	declarations : [ 
		SafeHtmlPipe,
		AppComponent,
		Pages.HomeComponent,
		Pages.HeaderComponent,
		Pages.FooterComponent,
		Pages.LoginComponent,
		Pages.RegisterComponent,
		Pages.UserRegisterComponent,
		LoginComponent,
		LoginLayoutComponent,
		AppLayoutComponent,
		AppHeaderComponent,
		AppFooterComponent
	],
	bootstrap : [ AppComponent ]
})


export class AppModule {
	constructor(){
		console.log('app module called');
	}
}

