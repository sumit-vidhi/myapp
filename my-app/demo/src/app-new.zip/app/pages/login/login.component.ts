import { 
	Component, 
	OnInit 
}	 					from '@angular/core';
import { 
	FormBuilder,
	FormGroup,
	Validators 
} 						from '@angular/forms';

import { LoginForm } from '../../models/login-form';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})


export class LoginComponent implements OnInit {
	constructor(
		private fb  : FormBuilder
	){}

	loginForm : FormGroup;
	model = new LoginForm();

  	ngOnInit() {
  		this.loginForm = this.fb.group({	
  			username : [this.model.username, Validators.required, Validators.email],
		 	password : [this.model.password, Validators.required],
		 	rememberMe : this.model.rememberMe
  		});
	}
}
