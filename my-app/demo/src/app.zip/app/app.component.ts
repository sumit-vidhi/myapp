import { 
	Component, 
	ViewEncapsulation, 
	OnInit 
} 							from '@angular/core';

import { AuthService } 		from './core/auth.service';

@Component({
	selector : 'app-root',
	templateUrl: './app.component.html',
	styles : ['./app.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class AppComponent implements OnInit {
	
	constructor(private auth: AuthService) {
	    // Check for authentication and handle if hash present
	    auth.handleAuth();
	 }

	ngOnInit() {
  	
  	}
}