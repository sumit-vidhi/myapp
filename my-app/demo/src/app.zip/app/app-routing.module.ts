import { NgModule } 		from '@angular/core';

import { 
	Routes, 
	RouterModule 
} 							         from '@angular/router';

import  * as Pages      from './pages';



const appRoutes: Routes = [
  {   path : '',                      component : Pages.UserRegisterComponent },
  { 	path : 'login',                 component : Pages.LoginComponent },
  {   path : 'register',              component : Pages.RegisterComponent },
	{ 	path : 'user/register',         component : Pages.UserRegisterComponent },
  {   path : 'home',                  redirectTo: '' },
];


@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],

  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}
