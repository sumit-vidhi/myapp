import { 
	Component, 
	OnInit,
	ViewChild,
	ViewEncapsulation
} 										from '@angular/core';

import { TabsetComponent } 				from 'ngx-bootstrap';
import { 
	FormBuilder, 
	FormGroup,
	Validators,
	ValidatorFn,
	AbstractControl 
} 										from '@angular/forms';


import { Router } 						from '@angular/router';
import { ApiService }					from '../../core/api.service';
import { AuthService }					from '../../core/auth.service';
import { UtilService }					from '../../core/util.service';
import { StorageService }				from '../../core/storage.service';



function passwordMatchValidator(g: FormGroup) {
   return g.get('password').value === g.get('confirm_password').value
      ? null : {'mismatch': true};
}

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: [
  	'../../../../node_modules/ngx-bootstrap/datepicker/bs-datepicker.css', 
  	'./user-register.component.css'],
  encapsulation:ViewEncapsulation.None
})


export class UserRegisterComponent implements OnInit {

	@ViewChild('staticTabs') staticTabs: TabsetComponent;

  	constructor(
		private fb  : FormBuilder,
		private api : ApiService,
		private auth : AuthService,
		public util : UtilService,
		private router : Router,
		private storage : StorageService
	){}

  	step : number = 0;
	regForm : FormGroup;

	createForm() {
		let self = this;
		 this.regForm = this.fb.group({	

		 	first_name : ['k', Validators.required],
		 	last_name : ['s', Validators.required],
		 	nickname : ['k', Validators.required],
		 	birth_date : [null,Validators.required],
		 	phone : ['1234567878', [ 
		 		Validators.required,  
		 		Validators.minLength(10),
		 		Validators.maxLength(10),
		 		Validators.pattern("[0-9]*")
		 	]],
		 	email : ['k@s.com', [ 
		 		Validators.required, 
		 		Validators.email
		 	]],
		 	password : ['123456', Validators.required],
		 	confirm_password : ['123456', Validators.required],

		 	street : 'E -41, Phase 8',
		 	city : 'Mohali',
		 	state : 'Punjab',
		 	country : 'India',
		 	zip : '160071',

		 	timezone:'',
		 	clock_display:'',
		 	primary_langauge:'',
		 	secondary_language:'',

		 	start_date: new Date(),
		 	description:'',

			step : this.step,
		},{ validator : passwordMatchValidator});
  	}

  	selectTab(tab_id: number) {
    	this.staticTabs.tabs[tab_id].active = true;
  	}

  	disableEnable(tab_id: number) {
    	this.staticTabs.tabs[tab_id].disabled = !this.staticTabs.tabs[tab_id].disabled;
  	}

	model : any = {};
	
	nextPrev(step) : void {
		if(step > 0) this.next();
		else  this.prev();
	}

	next() {
		if(++this.step > 3) this.step = 3;
		this.regForm.get('step').setValue(this.step);
		this.disableEnable(this.step);
		this.selectTab(this.step);
	}

	prev(){
		if(--this.step < 0) this.step = 0;
		this.selectTab(this.step);
	}

	removeAlert() : void{
		
	}

	submit() {
	}

	ngOnInit() {
		this.createForm();
		/*this.regForm.get('step').valueChanges.subscribe((step) => {
			if(step == 1){
				this.regForm.get('street').setValidators([Validators.required]);
				this.regForm.get('city').setValidators([Validators.required]);
				this.regForm.get('state').setValidators([Validators.required]);
				this.regForm.get('country').setValidators([Validators.required]);
				this.regForm.get('zip').setValidators([
					Validators.required,
					Validators.minLength(5),
		 			Validators.maxLength(6),
		 			Validators.pattern("[0-9]*")
				]);

				this.regForm.get('timezone').setValidators([Validators.required]);
				this.regForm.get('clock_display').setValidators([Validators.required]);
				this.regForm.get('primary_langauge').setValidators([Validators.required]);
				this.regForm.get('secondary_language').setValidators([Validators.required]);


				this.regForm.get('street').updateValueAndValidity();
				this.regForm.get('city').updateValueAndValidity();
				this.regForm.get('state').updateValueAndValidity();
				this.regForm.get('country').updateValueAndValidity();
				this.regForm.get('zip').updateValueAndValidity();

				this.regForm.get('timezone').updateValueAndValidity();
				this.regForm.get('clock_display').updateValueAndValidity();
				this.regForm.get('primary_langauge').updateValueAndValidity();
				this.regForm.get('secondary_language').updateValueAndValidity();

			} else if(step == 2){
				
				

			}
		});*/
  	}

}
