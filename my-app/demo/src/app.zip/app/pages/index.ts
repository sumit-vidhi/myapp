export { HomeComponent } 			from './home/home.component';
export { HeaderComponent }			from './header/header.component';
export { FooterComponent } 			from './footer/footer.component';
export { LoginComponent } 			from './login/login.component';
export { RegisterComponent } 		from './register/register.component';
export { UserRegisterComponent } 	from './user-register/user-register.component';