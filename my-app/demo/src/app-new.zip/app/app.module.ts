import { NgModule, Pipe, PipeTransform } 	from '@angular/core';
import { BrowserModule } 					from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule }  from '@angular/forms';
import { HttpClientModule } 				from '@angular/common/http';
import { CustomFormsModule } 				from 'ng2-validation'
import { Ng2Webstorage } 					from 'ng2-webstorage';
import { DomSanitizer } 					from '@angular/platform-browser';
import { AlertModule } 						from 'ngx-bootstrap';
import { BsDropdownModule } 				from 'ngx-bootstrap';
import { TabsModule } 						from 'ngx-bootstrap';
import { TooltipModule } 					from 'ngx-bootstrap';
import { BsDatepickerModule } 				from 'ngx-bootstrap';
import { RatingModule } 					from 'ngx-bootstrap';
import { SelectModule } 					from 'ng2-select';

import * as $	 							from 'jquery';
import * as _ 								from 'underscore';

/***********************************
 | IMPORING MODULES
 ***********************************/

 	import { AppRoutingModule } 			from './app-routing.module';
 	import { CoreModule } 					from './core/core.module';

/***********************************
 | IMPORING DIRECTIVES
 ***********************************/



/***********************************
 | IMPORING COMPONENTS
 ***********************************/

import { AppComponent } 					from './app.component';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';

import { SiteComponent } from './pages/site/site.component';
import { SiteLayoutComponent } from './layouts/site-layout/site-layout.component';
import { SiteHeaderComponent } from './layouts/site-header/site-header.component';
import { SiteFooterComponent } from './layouts/site-footer/site-footer.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { RegisterUserComponent } from './pages/register-user/register-user.component';
import { RegisterTrainerComponent } from './pages/register-trainer/register-trainer.component';
import { RegisterListComponent } from './pages/register-list/register-list.component';
import { NavbarComponent } from './pages/navbar/navbar.component';
import { PaymentComponent } from './pages/payment/payment.component';
import { MessageComponent } from './pages/message/message.component';

@Pipe({ name: 'safeHtml'})

export class SafeHtmlPipe implements PipeTransform  {
  constructor(private sanitized: DomSanitizer) {}
  transform(value) {
    return this.sanitized.bypassSecurityTrustHtml(value);
  }
}

@NgModule({
	imports : [ 
		BrowserModule, 
		FormsModule, 
		ReactiveFormsModule,
		HttpClientModule, 
		AlertModule.forRoot(),
		BsDropdownModule.forRoot(),
		TabsModule.forRoot(),
		BsDatepickerModule.forRoot(),
		TooltipModule.forRoot(),
		RatingModule.forRoot(),
		Ng2Webstorage,
		SelectModule,
		CustomFormsModule,
		AppRoutingModule,
		CoreModule.forRoot()
	],
	declarations : [ 
		SafeHtmlPipe,
		AppComponent,
		SiteComponent,
		PageNotFoundComponent,
		SiteLayoutComponent,
		SiteHeaderComponent,
		SiteFooterComponent,
		LoginComponent,
		RegisterComponent,
		RegisterUserComponent,
		RegisterTrainerComponent,
		RegisterListComponent,
		NavbarComponent,
		PaymentComponent,
		MessageComponent
	],
	bootstrap : [ AppComponent ]
})


export class AppModule {
	constructor(){
		console.log('app module called');
	}
}

