import { Component, OnInit } 		from '@angular/core';
import { 
	FormBuilder, 
	FormGroup,
	Validators 
} 									from '@angular/forms';

import { Router } 					from '@angular/router';
import { ApiService }				from '../../core/api.service';
import { AuthService }				from '../../core/auth.service';
import { StorageService }			from '../../core/storage.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
	
	loginForm : FormGroup;
	email : string;
	password : string;;
	remember_me : boolean;

	alerts : any;
	dismissible = true;

	constructor(
		private fb  : FormBuilder,
		private api : ApiService,
		private auth : AuthService,
		private router : Router,
		private storage : StorageService
	){}

	createForm() {
		 this.loginForm = this.fb.group({	 
	    	email : ['kuldeep@wegile.com', [ Validators.required, Validators.email ]],
	    	password : ['123456', Validators.required ],
	    	remember_me : [1]
	  	});
  	}

  	login(model) {
  		this.api
		.login(model)
		.then((res)=>{
			if(res.code === 200) {
				this.auth.setToken(res.token);
				this.auth.login();				
			}	
			else{ 	
				this.showError("Either email or password is wrong");
			}	
		});
  	}

  	showError(msg : string){
  		this.alerts = [{
  			type: 'danger',
      		msg : msg
    	}];
  	}
  	
  	removeError(): void {
    	this.alerts = this.alerts.map((alert: any) => Object.assign({}, alert));
  	}

	submit(model) {
		if(this.loginForm.valid)
			this.login(this.loginForm.value);
	} 

  	ngOnInit() {
  		this.createForm();
  	}
}
