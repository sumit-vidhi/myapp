export class Country {
	text : string;
	id : string;
}
