import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';



import { SiteLayoutComponent } 		from './layouts/site-layout/site-layout.component';
import { LoginComponent } 			from './pages/login/login.component';
import { SiteComponent } 			from './pages/site/site.component';
import { RegisterComponent }		from './pages/register/register.component';
import { RegisterListComponent }	from './pages/register-list/register-list.component';
import { RegisterUserComponent }	from './pages/register-user/register-user.component';
import { RegisterTrainerComponent }	from './pages/register-trainer/register-trainer.component';
import { PaymentComponent } 		from './pages/payment/payment.component';
import { MessageComponent } 		from './pages/message/message.component';
import { PageNotFoundComponent }	from './pages/page-not-found/page-not-found.component';


const routes: Routes = [
  { path: '', 
  	component: SiteLayoutComponent,
  	children : [
  		{ path:'', component: SiteComponent, pathMatch:'full' }
	],
	pathMatch : 'full'
  },
  { 
  	path: 'register', 
  	component: RegisterComponent,
  	children : [
  		{ path:'user', component: RegisterUserComponent},
  		{ path:'trainer', component: RegisterTrainerComponent},
  		{ path:'', component: RegisterListComponent, pathMatch:'full' }
  	]
  },
  { path: 'login', component: LoginComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'message', component: MessageComponent },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
	imports: [ RouterModule.forRoot(routes) ],
  	exports: [ RouterModule ]
})


export class AppRoutingModule {}